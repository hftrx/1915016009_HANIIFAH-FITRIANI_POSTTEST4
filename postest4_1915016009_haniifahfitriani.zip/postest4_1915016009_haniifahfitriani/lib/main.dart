import 'package:flutter/material.dart';
import 'package:postest4_1915016009_haniifahfitriani/showroomcar.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "postest4_1915016009_haniifah fitriani",
      home: showroomcar(),
    );
  }
}
